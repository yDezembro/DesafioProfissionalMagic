package gsdproject.dp6s;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dp6sApplicationTests {

	@Test
	void contextLoads() {
	}

}
