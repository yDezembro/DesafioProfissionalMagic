package gsdproject.dp6s;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dp6sApplication {

	public static void main(String[] args) {
		SpringApplication.run(Dp6sApplication.class, args);
	}

}
